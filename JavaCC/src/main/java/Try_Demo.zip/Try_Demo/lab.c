void main() {
    int a = 2, b;
    while (a > 0) {
a = a - 1; }
print(a); }
