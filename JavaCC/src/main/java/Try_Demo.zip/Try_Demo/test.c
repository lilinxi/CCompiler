#include <iostream>
#define X 2
#include "my.h"
#define Y 2
int a=12;
loop: int fun();
int b=a;
#define Z 3
int fun1(int p,int q);
int fun2(int var1,int var2,...){}

goto loop:
a=11;
if(11){
    int a=1;
    if(1){
        a=3;
    }
}else{
    a=2;
}
while(13){
    a=1;
}
do{
    a=3;
}while(a);
for(int i=0;i++;i<4){
    i=1;
}
for(;;){
    if(true){
       continue;
    }else{
        return;
    }
}
switch(a){
    case 1:break;
    case 2:a=1;
    default:a=3;
}
//ad
/*e*/